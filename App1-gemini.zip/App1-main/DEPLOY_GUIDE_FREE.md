# Free Deployment Guide — Stock Advisor AI India

Total cost: ₹0/month. Total time: ~30 min first time. Updates auto-deploy.

## Stack
- **MongoDB Atlas** (free 512 MB, Mumbai region)
- **Render.com** free web service (FastAPI backend)
- **Netlify** free static hosting (React frontend)
- **UptimeRobot** free pinger (keeps Render awake)

---

## Phase 1 — Push code to GitHub
1. Open Emergent → profile → **Push to GitHub** → authorize → create new repo `stock-advisor-ai-india` → Push.

## Phase 2 — MongoDB Atlas
1. https://cloud.mongodb.com → Build a Database → **M0 Free**, AWS, Mumbai (ap-south-1).
2. Create user `stockadvisor` (autogen password — copy it).
3. Network Access → Add IP `0.0.0.0/0`.
4. Connect → Drivers → copy connection string.
5. Replace `<db_password>` with your password and add `/stockadvisor` before `?`. Save as `MONGO_URL`.

## Phase 3 — Render backend
1. Get `EMERGENT_LLM_KEY` from Emergent profile → Universal Key.
2. https://dashboard.render.com → New + → Web Service → connect repo.
3. Settings:
   - Name: `stock-advisor-backend`
   - Region: Singapore
   - Root Directory: `backend`
   - Runtime: Python 3
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn server:app --host 0.0.0.0 --port $PORT`
   - Instance Type: **Free**
4. Environment variables:
   - `MONGO_URL` = (full Atlas string)
   - `DB_NAME` = `stockadvisor`
   - `CORS_ORIGINS` = `*` (lock down later)
   - `EMERGENT_LLM_KEY` = (from step 1)
   - `PYTHON_VERSION` = `3.11.0`
5. Deploy → wait ~6 min → verify `https://your-backend.onrender.com/api/health` returns `{"status":"ok","llm_configured":true}`.

## Phase 4 — Netlify frontend
1. https://app.netlify.com → Add new site → Import → GitHub → select repo.
2. Settings:
   - Base directory: `frontend`
   - Build command: `yarn build`
   - Publish directory: `frontend/build`
3. Environment variables:
   - `REACT_APP_BACKEND_URL` = your Render URL (no trailing slash)
   - `CI` = `false`
   - `NODE_VERSION` = `18`
4. Deploy → rename site to `stockadvisor-india` → URL is `https://stockadvisor-india.netlify.app`.

## Phase 5 — Lock CORS
1. Render → Environment → change `CORS_ORIGINS` to your Netlify URL (e.g. `https://stockadvisor-india.netlify.app`) → Save.

## Phase 6 — UptimeRobot (avoid Render sleep)
1. https://uptimerobot.com → New monitor → HTTP(s) → URL `https://your-backend.onrender.com/api/health` → 5 min interval → Create.

## Phase 7 — Add to phone home screen
- Android Chrome → ⋮ → Add to Home screen.
- iPhone Safari → Share → Add to Home Screen.

## Updates
Push to GitHub from Emergent → both Netlify + Render auto-redeploy in 3–5 min.

## Common fixes
- 50-sec first load → Render sleep. Set up UptimeRobot.
- CORS error → match `CORS_ORIGINS` to Netlify URL exactly, no trailing slash.
- `Treating warnings as errors` build fail → `CI=false` env var on Netlify.
- LLM key error → check `EMERGENT_LLM_KEY` on Render.
