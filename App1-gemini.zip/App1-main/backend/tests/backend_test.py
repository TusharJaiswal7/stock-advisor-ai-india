"""Backend tests for Stock Advisor AI India"""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL") or "https://nifty-swing-trader.preview.emergentagent.com"
BASE_URL = BASE_URL.rstrip("/")
TIMEOUT = 90


@pytest.fixture(scope="module")
def client():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


# ---------- Health ----------
def test_health(client):
    r = client.get(f"{BASE_URL}/api/health", timeout=15)
    assert r.status_code == 200
    j = r.json()
    assert j.get("status") == "ok"
    assert j.get("llm_configured") is True


# ---------- Today Plan ----------
def test_today_plan_structure(client):
    r = client.post(f"{BASE_URL}/api/today-plan", timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    d = r.json()
    required = ["market_mood", "nifty_trend", "buy_today", "hold", "sell",
                "avoid_today", "capital_strategy", "mood_reason", "nifty_note"]
    for k in required:
        assert k in d, f"missing {k}"
    assert isinstance(d["buy_today"], list) and len(d["buy_today"]) == 3
    for item in d["buy_today"]:
        assert "symbol" in item and "name" in item and "reason" in item and "buy_range" in item


def test_today_plan_force_refresh(client):
    r1 = client.post(f"{BASE_URL}/api/today-plan", timeout=TIMEOUT)
    assert r1.status_code == 200
    r2 = client.post(f"{BASE_URL}/api/today-plan", params={"force": "true"}, timeout=TIMEOUT)
    assert r2.status_code == 200
    d2 = r2.json()
    assert "market_mood" in d2
    assert "generated_at" in d2


# ---------- Stock Pick ----------
def test_stock_pick_specific(client):
    r = client.post(f"{BASE_URL}/api/stock-pick", json={"symbol": "ITC"}, timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    d = r.json()
    numeric_fields = ["current_price", "buy_range_low", "buy_range_high", "qty",
                      "stop_loss", "target_1", "target_2", "expected_days",
                      "risk_score", "charges_estimate", "net_profit_t1", "net_profit_t2"]
    for f in numeric_fields:
        assert f in d, f"missing {f}"
        assert isinstance(d[f], (int, float)), f"{f} not numeric: {d[f]}"
    assert "risk_label" in d
    assert "why_selected" in d and len(d["why_selected"]) > 0
    assert "key_risks" in d


def test_stock_pick_auto(client):
    r = client.post(f"{BASE_URL}/api/stock-pick", json={"symbol": None}, timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    d = r.json()
    assert "symbol" in d and len(d["symbol"]) > 0
    assert "current_price" in d


# ---------- Portfolio Advice ----------
def test_portfolio_advice(client):
    payload = {"holdings": [{"symbol": "RELIANCE", "qty": 5, "buy_price": 2800}]}
    r = client.post(f"{BASE_URL}/api/portfolio-advice", json=payload, timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    d = r.json()
    assert "items" in d and isinstance(d["items"], list) and len(d["items"]) >= 1
    item = d["items"][0]
    for k in ["symbol", "current_price", "advice", "exit_target", "stop_loss", "reason"]:
        assert k in item, f"missing {k}"
    assert item["advice"] in ["HOLD", "SELL", "ADD", "TRIM"]


def test_portfolio_advice_empty(client):
    r = client.post(f"{BASE_URL}/api/portfolio-advice", json={"holdings": []}, timeout=30)
    assert r.status_code == 200
    assert r.json() == {"items": []}


# ---------- price_source enrichment ----------
def test_stock_pick_price_source(client):
    r = client.post(f"{BASE_URL}/api/stock-pick", json={"symbol": "INFY"}, timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    d = r.json()
    assert "price_source" in d
    assert d["price_source"] in ("ai_estimate", "live")


def test_portfolio_advice_price_source(client):
    payload = {"holdings": [{"symbol": "TCS", "qty": 2, "buy_price": 3500}]}
    r = client.post(f"{BASE_URL}/api/portfolio-advice", json=payload, timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    items = r.json()["items"]
    assert len(items) >= 1
    for it in items:
        assert "price_source" in it
        assert it["price_source"] in ("ai_estimate", "live")


# ---------- Live Price ----------
def test_live_price_default_unavailable(client):
    r = client.get(f"{BASE_URL}/api/live-price/RELIANCE", timeout=15)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["symbol"] == "RELIANCE"
    assert d["price"] is None
    assert d["source"] == "unavailable"
    assert d["provider_configured"] is False


def test_live_price_uppercases_symbol(client):
    r = client.get(f"{BASE_URL}/api/live-price/reliance", timeout=15)
    assert r.status_code == 200
    assert r.json()["symbol"] == "RELIANCE"


# ---------- Portfolio Plan ----------
def test_portfolio_plan_structure(client):
    payload = {"capital": 25000, "risk_appetite": "conservative"}
    r = client.post(f"{BASE_URL}/api/portfolio-plan", json=payload, timeout=120)
    assert r.status_code == 200, r.text
    d = r.json()
    for k in ["total_capital", "deployed", "reserve", "reserve_reason",
              "strategy_note", "picks"]:
        assert k in d, f"missing {k}"
    assert isinstance(d["picks"], list)
    assert 3 <= len(d["picks"]) <= 4, f"expected 3-4 picks, got {len(d['picks'])}"

    # Sum of allocations + reserve ≈ 25000 (±5%)
    alloc_sum = sum(p.get("allocation", 0) for p in d["picks"])
    total = alloc_sum + d["reserve"]
    assert abs(total - 25000) <= 25000 * 0.05, f"alloc+reserve {total} far from 25000"

    pick_fields = ["symbol", "name", "sector", "allocation", "current_price",
                   "buy_range_low", "buy_range_high", "qty", "stop_loss",
                   "target_1", "target_2", "expected_days", "risk_score",
                   "risk_label", "charges_estimate", "net_profit_t1",
                   "net_profit_t2", "why_selected", "key_risks", "price_source"]
    for p in d["picks"]:
        for f in pick_fields:
            assert f in p, f"pick missing {f}: {p}"
        assert p["price_source"] in ("ai_estimate", "live")
