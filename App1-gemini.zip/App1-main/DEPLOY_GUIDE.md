# Complete Deployment Guide - Stock Advisor AI India

(See the chat message from your assistant for the full step-by-step.)

## Quick reference - your app's env vars

### Backend (/app/backend/.env)
- MONGO_URL          (your MongoDB Atlas URI)
- DB_NAME            (e.g. stockadvisor)
- CORS_ORIGINS       (=* for now)
- EMERGENT_LLM_KEY   (already set: sk-emergent-...)
- STOCK_API_PROVIDER (optional: yfinance | alpha_vantage | twelve_data)
- STOCK_API_KEY      (optional - paste your free key when ready)

### Frontend (/app/frontend/.env)
- REACT_APP_BACKEND_URL = the public URL of your backend (Render or Emergent)

## Render Web Service settings (if using Netlify+Render path)
- Root Directory : backend
- Build Command  : pip install -r requirements.txt
- Start Command  : uvicorn server:app --host 0.0.0.0 --port $PORT
- Runtime        : Python 3.11

## Netlify build settings (if using Netlify+Render path)
- Base directory   : frontend
- Build command    : yarn build
- Publish directory: build
